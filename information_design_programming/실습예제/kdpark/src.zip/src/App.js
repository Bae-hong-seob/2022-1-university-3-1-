import logo from './logo.svg';
import Hello from './Hello'; // export Hello를 import한 것. 따라서 조각조각 개발 가능
import Wrapper from './Wrapper';
import './App.css';

function App() {
  return (
    <Wrapper>
      <Hello name = 'Kw' color = 'red' isSpecial = {true}/>
      <Hello name = 'S' color = 'green' isSpecial = {false}/>
    </Wrapper>
  ); 
}

export default App;
