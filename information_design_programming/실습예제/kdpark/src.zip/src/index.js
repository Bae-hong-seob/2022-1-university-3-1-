import React from 'react';
import ReactDOM from 'react-dom/client';
import './index.css';
import App from './App';
import reportWebVitals from './reportWebVitals';

const root = ReactDOM.createRoot(document.getElementById('root')); // 가장 먼저 실행되는 파일 index.js
root.render( // root가 render 시작됨. 뭐가? 
  <React.StrictMode>
    <App /> 
  </React.StrictMode>
); // App.js를 렌더링하면 그 속에 Hello 컴포넌트가 있으므로 다시 Hello.js 파일로 가서 렌더링을 하게 된다.
// <React.StrictMode> 잠재적인 문제 발생시 경고를 알려주는 기능. 따라서 개발시에만 넣고 진행. 배포때는 삭제하고 진행함.

// If you want to start measuring performance in your app, pass a function
// to log results (for example: reportWebVitals(console.log))
// or send to an analytics endpoint. Learn more: https://bit.ly/CRA-vitals
reportWebVitals();
