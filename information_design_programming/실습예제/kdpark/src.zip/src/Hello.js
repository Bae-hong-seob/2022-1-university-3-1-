 import React from "react";

 function Hello({name, color, isSpecial}) {// 바벨(Babel) -> JSX라고 XML 형식의 값을 반환해주는 특수한 문법임. 바벨이라고 부름. -> retrun에 쓰는 문법.
    const dept = "정융"; // 변수 선언도 가능
    const style = {
        backgroundColor: 'black', // background-color
        color: 'aqua',
        fontSize: 24, // 기본 단위 px
        padding: '1rem' // 다른 단위 사용 시 문자열로 설정
    }
     return ( // 1) 전체는 하나의 태그로 묶여있어야하고 -> <> 빈 태그 사용 2)태그는 꼭 닫혀 있어야 하고 3) 단독 태그의 경우 <br /> 꼭 써야됨
     <>
        <div style={{color}}>Hello world!
            <br />
            안녕하세요!
            {isSpecial ? <b>반갑습니다</b> : <b>머요 ㅋㅋ</b>} 
            {/* {isSpecial && <b>반갑습니다</b>} */}
         </div> 
         <div style={style}>{name}대학교 {dept} 박규동입니다</div> 
     </>
     );
 }

 Hello.defaultProps = {
     name: "이름없음"
 }

 export default Hello; // 이렇게 하면 Hello라는 함수를 컴포넌트화 시켜서 export(수출) 시킴. 다른 파일에서 import 가능해짐 -> App.js 보셈