import React, { useState } from "react";

// 확장성이 좋지 않은 방법. Input 개수가 늘어날때마다 hook 함수가 늘어난다. -> state hook도 늘어난다. 렌더링이 계속 된다.
// 따라서 객체로 다루는게 효율적이다. 객체위주의 방식으로 코드를 짤 필요가 있음.
function Multi_Input() { 
    //  text의 default 값 빈칸. ''할당
    const [name, setName] = useState("");
    const [nickname, setNickname] = useState("");
    // onChange의 인자 e를 활용하여 target value로 text 내용 수정
    const onChange_name = (e) => { setName(e.target.value); }; 
    const onChange_nickname = (e) => { setNickname(e.target.value); }; 
    // onReset 시 text 값에 '' 할당하는 setText함수 실행
    const onReset = () => { 
        setName(""); 
        setNickname("");
    };

    return (
    <div>
    <input placeholder="이름" onChange={onChange_name} value={name} />
    <input placeholder="닉네임" onChange={onChange_nickname} value={nickname} />
    <button onClick={onReset}>초기화</button> <div>
    <b>이름 : {name}</b> <br />
    (닉네임) : {nickname}</div>
    </div>
    ); 
}

export default Multi_Input;