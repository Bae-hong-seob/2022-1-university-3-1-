import React, { useState, useRef} from "react";

// 확장성이 좋지 않은 방법. Input 개수가 늘어날때마다 hook 함수가 늘어난다. -> state hook도 늘어난다. 렌더링이 계속 된다.
// 따라서 객체로 다루는게 효율적이다. 객체위주의 방식으로 코드를 짤 필요가 있음.
function Multi_Input_object() { 
    // useState 인자를 객체로 전달
    const [inputs, setInputs] = useState({
        name : '',
        nickname : '',
        phone : '',
    });

    const {name, nickname, phone} = inputs; // inputs으로 부터 값을 빼온 것. 분해할당이라고 한다. 수정은 setInputs를 통해서만.
    const nameInput = useRef();

    // onChange의 인자 e를 활용하여 target value로 text 내용 수정
    const onChange = (e) => { 
        const {value, name, phone} = e.target; // 여기서 name은 input 간의 구분자 역할을 하는 id 같은것.
        setInputs({
            ...inputs,
            [name]: value, // input의 id : value 를 뜻함
        });
    }; 
    // onReset 시 text 값에 '' 할당하는 setText함수 실행
    const onReset = () => { 
        setInputs({
            name : "",
            nickname : '',
            phone : '',
        });
        nameInput.current.focus();
    };

    return (
    <div>
    <input name = 'name' placeholder="이름" onChange={onChange} value={name} ref={nameInput}/>
    <input name = 'nickname' placeholder="닉네임" onChange={onChange} value={nickname} />
    <input name = 'phone' placeholder="전화번호" onChange={onChange} value={phone} />
    <button onClick={onReset}>초기화</button> <div>
    <b>이름 : {name}</b> <br />
    (닉네임) : {nickname} <br />
    전화번호 : {phone}</div>
    </div>
    ); 
}

export default Multi_Input_object;