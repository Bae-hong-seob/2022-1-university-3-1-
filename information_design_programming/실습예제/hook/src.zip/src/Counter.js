import React from "react";
import App from "./App";

function Counter() {
    let number = 0;

    const OnIncreas = () => {
        number +=1;
        document.getElementById("answer").innerText = number; // react와 같은 라이브러리 말고 자바스크립트를 사용하는 것을 바닐라제이스라고 한다.
        console.log(number);
    }

    const OnDecreas = () => {
        number -=1;
        document.getElementById("answer").innerText = number;
        console.log(number);
    }
    return (
    <div> 
        <h1 id = "answer">{number}</h1> {/* id 속성 추가해주기. 그래야 접근이 가능 */}
        <button onClick={OnIncreas}>+1</button>
        <button onClick={OnDecreas}>-1</button>
    </div>
    );
}

export default Counter;