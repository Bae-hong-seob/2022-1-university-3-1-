import logo from './logo.svg';
import './App.css';
import Counter from './Counter';
import Hook_counter from './hook';
import InputSample from './InputSample';
import Multi_Input from './multi_Input';
import Multi_Input_object from './Multi_Input_object';
import UserList from './UserList';

function App() {
  return <Multi_Input_object />//<UserList />//<Multi_Input_object />//<Multi_Input / > //<InputSample />; //<Hook_counter />;     //<Counter />; 
}

export default App;
