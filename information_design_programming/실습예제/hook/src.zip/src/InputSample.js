import React, { useState } from "react";

function InputSample() {
    //  text의 default 값 빈칸. ''할당
    const [text, setText] = useState("");
    // onChange의 인자 e를 활용하여 target value로 text 내용 수정
    const onChange = (e) => { setText(e.target.value); }; 
    // onReset 시 text 값에 '' 할당하는 setText함수 실행
    const onReset = () => { setText(""); };

    return (
        <div>
        <input onChange={onChange} value={text} /> 
        <button onClick={onReset}>초기화</button> 
        <div><b>값: {text}</b> </div>
        </div>
    ); 
}
export default InputSample;