import React, { useState } from "react";
import App from "./App";

{/* hook이란?
함수 컴포넌트에서 React state와 생명주기 기능(lifecycle features)을 “연동(hook into)“할 수 있게 해주는 함수
− State Hook
− Effect Hook 
*/}

function Hook_counter() {
    const [number, setNumber] = useState(0); 
    // number : 현재 상태(값) , setNumber : Setter 함수 (값을 수정하는 수식)
    // useState 는 성능을 위하여 일괄 배치(batch) 함수로 동작.
    // 따라서 렌더링할때 한꺼번에 처리. 만약 겹치는게 있다면 맨 마지막에 호출된 함수만 적용됨. 

    const OnIncreas = () => {
        //setNumber(number + 1); // react 엔진이 값이 변하는지 확인하고 있다가 변하게 되면 setNumber 함수 바로 적용. 따라서 react를 쓰는 이유 
        //setNumber(number + 10);

        //마지막 update된 값이 적용되기 때문에 여러번 연산을 수행하고 싶으면 함수의 형태로 update를 동작함. 
        setNumber(n => n+1);
        setNumber(n => n+1);
        setNumber(n => n+1); // 3씩 증가하는거 확인가능
        
        console.log(number); // id 없이 요소에 접근 가능.
    };

    const OnDecreas = () => {
        setNumber(number - 1);
        console.log(number);
    };

    return (
    <div> 
        <h1>{number}</h1> {/* id 속성 추가해주기. 그래야 접근이 가능 */}
        <button onClick={OnIncreas}>+1</button>
        <button onClick={OnDecreas}>-1</button>
    </div>
    );
};

export default Hook_counter;