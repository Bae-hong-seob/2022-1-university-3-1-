import React, { useState } from "react";

function User({ user }) { // user 객체로 전달.
    return (
    <div> <b>{user.username}</b>
    <span>({user.email})</span>
    </div>
    )
}

function UserList() {
    const users = [
        {   
            id: 1,
            username: "kdpark", 
            email: "kdpark@kw.ac.kr",
        }, 
        {
            id: 2,
            username: "admin",
            email: "admin@kw.ac.kr",
        }, 
        {
            id: 3,
            username: "root",
            email: "sudo@kw.ac.kr",
        }, 
        {
            id: 4,
            username: "root",
            email: "sudo@kw.ac.kr",
        }
    ];
    
    // 객체 지향언어 x 그냥 노가다 한거
    // return <div> <b>{users[0].username}</b>
    // <span>({users[0].email})</span>
    // </div>

    // return ( // User 함수의 인자명으로 호출해야한다.
    //     <>
    //     <User user={users[0]} /> 
    //     <User user={users[1]} />
    //     <User user={users[2]} />
    //     </>
    // );

    // 저거도 노가다. 그냥 map 함수를 활용하여 동적 할당을 이루어내자.
    return (
        <div>
        {users.map(user => (
            <User user={user} />
        ))}
        </div>
    )

    // // key-ID mapping
    // return (
    //     <div>
    //     {users.map((user, index) => (
    //         <User user={user} key={index} />
    //     ))} 
    //     </div>
    // )
}

export default UserList;