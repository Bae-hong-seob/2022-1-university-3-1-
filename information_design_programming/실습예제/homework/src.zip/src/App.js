import logo from './logo.svg';
import './App.css';
import CreateTask from './CreateTask';
import TaskList from './TaskList';

import React, { useState, useRef} from "react";

function App() {

  // task리스트 제작
  const [tasks, setTasks] = useState([ 
    {
      id : 0,
      tasks:'할일하기',
    },
    {
      id: 1,
      tasks:'운동하기'
    }, 
    {
      id: 2,
      tasks:'청소하기'
    }, 
]); 

  const onRemove = (id) => {
  setTasks(tasks.filter((user) => user.id !== id)); 
  };

  // CreateTask와 TaskList에 tasks(할일목록) 보내기
  return ( <>
  <CreateTask name='createTask'tasks={tasks} setTasks={setTasks}/>
  <TaskList name='taskList'tasks={tasks} onRemove={onRemove}/>
  </>
  ); 

}

export default App;
