import React, { useRef, useState } from "react";

//id의 고유값을 할당하기 위해 변수 선언.
let n=3;

function CreateTask({tasks, setTasks}) { 

    const [inputs, setInputs] = useState('');
    const onChange = (e) => {
        setInputs(e.target.value); 
     };

     //등록 버튼 눌렀을때 초기화 위치
    const nameInput = useRef();

    const onCreate = () => { 
        //input창이 비어있다면 경고창 발생
        if (inputs === '') {
            alert("내용을 입력하세요.")
        }
        
        else {
        const nextTaskList = tasks.concat({ 
            //id: tasks.length,  
            id: n+1, 
            // tasks.length로 선언했을 때는 삭제했다가 재 등록시 id가 겹치는 현상이 발생.
            // 또한 id 값으로 useRef.current를 사용하면, current 속성을 가지고 있는 객체를
            // 반환값을 id값으로 가지게 되는데, 이때 여러개 등록하고 윗항목을 삭제시 아랫항목까지 모두 삭제되는 경우가 발생.
            // 예를 들어 기존 1,2,3 항목이 있을때 4,5,6,7 항목을 등록하고 5 항목을 삭제하면 5,6,7이 모두 삭제됨.
            // 이는 현재 current의 값이 동일하여 id가 중복되어 나타나는 현상이므로 전역변수 n을 선언하여 
            // 리스트를 등록할때마다 n+1 의 값을 할당함으로써 id 중복을 피하게 구현하였다.
            tasks: inputs,
        }); 

        setTasks(nextTaskList);
        //n값 증가
        n+=1;
        };
        
        setInputs("");
        nameInput.current.focus();
    };

    return (
    <div>
    <input placeholder="할일" onChange={onChange} value={inputs} ref={nameInput}/>
    <button onClick={onCreate}>등록</button>
    </div>
    ); 
}

export default CreateTask;