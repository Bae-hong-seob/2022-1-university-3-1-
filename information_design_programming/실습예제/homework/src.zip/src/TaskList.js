import React, { useState } from "react";

function Task({ task , onRemove}) { 

    return (
        <div><b>{task.tasks}</b>
        <span><button onClick={() => onRemove(task.id)}>삭제</button></span>
        </div>

    )
}

function Tasklist({tasks, onRemove}) {
    // map함수 사용
    return (
        <div>
        {tasks.map(task => (
          <div>
            <Task task={task} onRemove={onRemove}/>
          </div>
        ))}
        </div>
    )

}

export default Tasklist;